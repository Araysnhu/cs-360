package com.example.weighttrackapp.ui.theme;

// WeightEntry.java (Data model for weight entries)


public class WeightEntry {
    private int id;
    private String date;
    private double weight;
    private double weightGoal;
    private String notes;
    private String userId; // Add this field to associate with a user

    public WeightEntry(String date, double weight, double weightGoal, String notes) {
        this.date = date;
        this.weight = weight;
        this.weightGoal = weightGoal;
        this.notes = notes;
    }

    // Constructor including userId
    public WeightEntry(String date, double weight, double weightGoal, String notes, String userId) {
        this.date = date;
        this.weight = weight;
        this.weightGoal = weightGoal;
        this.notes = notes;
        this.userId = userId;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getWeightGoal() {
        return weightGoal;
    }

    public void setWeightGoal(double weightGoal) {
        this.weightGoal = weightGoal;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    // Getter and setter for userId
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}