package com.example.weighttrackapp.ui.theme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context; // Import Context
import android.content.Intent;
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.weighttrackapp.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class AddDataActivity extends AppCompatActivity {

    private TextInputLayout dateLayout;
    private TextInputEditText dateEditText;
    private TextInputLayout weightLayout;
    private TextInputEditText weightEditText;
    private TextInputLayout weightGoalLayout;
    private TextInputEditText weightGoalEditText;
    private TextInputLayout notesLayout;
    private TextInputEditText notesEditText;
    private Button saveButton;
    private Button cancelButton;
    private Button createButton;

    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences; // Add SharedPreferences

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        dbHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE); // Initialize SharedPreferences

        dateLayout = findViewById(R.id.dateLayout);
        dateEditText = findViewById(R.id.dateEditText);
        weightLayout = findViewById(R.id.weightLayout);
        weightEditText = findViewById(R.id.weightEditText);
        weightGoalLayout = findViewById(R.id.weightGoalLayout);
        weightGoalEditText = findViewById(R.id.weightGoalEditText);
        notesLayout = findViewById(R.id.notesLayout);
        notesEditText = findViewById(R.id.notesEditText);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
        createButton = findViewById(R.id.createButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = dateEditText.getText().toString().trim();
                String weightStr = weightEditText.getText().toString().trim();
                String weightGoalStr = weightGoalEditText.getText().toString().trim();
                String notes = notesEditText.getText().toString().trim();

                if (date.isEmpty()) {
                    dateLayout.setError("Date is required");
                } else {
                    dateLayout.setError(null);
                }

                if (weightStr.isEmpty()) {
                    weightLayout.setError("Weight is required");
                } else {
                    weightLayout.setError(null);
                }

                if (!date.isEmpty() && !weightStr.isEmpty()) {
                    try {
                        double weight = Double.parseDouble(weightStr);
                        double weightGoal = weightGoalStr.isEmpty() ? 0.0 : Double.parseDouble(weightGoalStr);

                        // Retrieve the logged-in user's ID
                        String loggedInUser = sharedPreferences.getString("loggedInUser", null);

                        if (loggedInUser != null) {
                            WeightEntry newEntry = new WeightEntry(date, weight, weightGoal, notes, loggedInUser);
                            if (dbHelper.addWeightEntry(newEntry)) {
                                Toast.makeText(AddDataActivity.this, "Data saved successfully", Toast.LENGTH_SHORT).show();
                                finish(); // Go back to the weight data screen
                            } else {
                                Toast.makeText(AddDataActivity.this, "Failed to save data", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(AddDataActivity.this, "User session error", Toast.LENGTH_SHORT).show();
                            // Handle the case where the user is not logged in properly
                        }
                    } catch (NumberFormatException e) {
                        weightLayout.setError("Invalid weight format");
                        weightGoalLayout.setError("Invalid weight goal format");
                    }
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the weight data screen
            }
        });

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddDataActivity.this, SMSPermissionActivity.class);
                startActivity(intent);
            }
        });
    }
}