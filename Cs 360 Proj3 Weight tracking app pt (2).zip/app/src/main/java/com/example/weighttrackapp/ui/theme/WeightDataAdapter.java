package com.example.weighttrackapp.ui.theme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.weighttrackapp.R;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightDataAdapter extends RecyclerView.Adapter<WeightDataAdapter.ViewHolder> {

    private Context context;
    private List<WeightEntry> weightEntries;

    public WeightDataAdapter(Context context, List<WeightEntry> weightEntries) {
        this.context = context;
        this.weightEntries = weightEntries;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_weight_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.dateTextView.setText("Date: " + entry.getDate());
        holder.weightTextView.setText("Weight: " + String.valueOf(entry.getWeight()) + " lbs");
        holder.goalTextView.setText("Goal: " + String.valueOf(entry.getWeightGoal()) + " lbs");
        holder.notesTextView.setText("Notes: " + entry.getNotes());
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView;
        TextView weightTextView;
        TextView goalTextView;
        TextView notesTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            goalTextView = itemView.findViewById(R.id.goalTextView);
            notesTextView = itemView.findViewById(R.id.notesTextView);
        }
    }
}