package com.example.weighttrackapp.ui.theme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.weighttrackapp.R;

public class SMSPermissionActivity extends AppCompatActivity {

    private Button grantPermissionButton;
    private Button denyPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        grantPermissionButton = findViewById(R.id.grantPermissionButton);
        denyPermissionButton = findViewById(R.id.denyPermissionButton);

        grantPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to AddDataActivity
                Intent intent = new Intent(SMSPermissionActivity.this, AddDataActivity.class);
                startActivity(intent);
                finish(); // Optional: Close SMSPermissionActivity
            }
        });

        denyPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to AddDataActivity
                Intent intent = new Intent(SMSPermissionActivity.this, AddDataActivity.class);
                startActivity(intent);
                finish(); // Optional: Close SMSPermissionActivity
            }
        });
    }
}