package com.example.weighttrackapp.ui.theme;

import android.content.Context; // Import Context
import android.content.Intent;
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.weighttrackapp.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    private TextInputLayout usernameLayout;
    private TextInputEditText usernameEditText;
    private TextInputLayout passwordLayout;
    private TextInputEditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private TextView forgotPasswordButton;
    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences; // Add SharedPreferences

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE); // Initialize SharedPreferences

        usernameLayout = findViewById(R.id.usernameLayout);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordLayout = findViewById(R.id.passwordLayout);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        forgotPasswordButton = findViewById(R.id.forgotPasswordButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (username.isEmpty()) {
                    usernameLayout.setError("Username is required");
                } else {
                    usernameLayout.setError(null);
                }

                if (password.isEmpty()) {
                    passwordLayout.setError("Password is required");
                } else {
                    passwordLayout.setError(null);
                }

                if (!username.isEmpty() && !password.isEmpty()) {
                    if (dbHelper.checkUser(username, password)) {
                        Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                        // Store the logged-in username in SharedPreferences
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("loggedInUser", username);
                        editor.apply();

                        Intent intent = new Intent(MainActivity.this, WeightDataActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(MainActivity.this, "Login failed. Incorrect username or password.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
                startActivity(intent);
            }
        });

        forgotPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Forgot Password functionality not implemented yet.", Toast.LENGTH_SHORT).show();
                // Implement forgot password logic here in a real application
            }
        });
    }
}