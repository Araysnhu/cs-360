package com.example.weighttrackapp.ui.theme;

// WeightDataActivity.java (for displaying weight data in a grid)


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context; // Import Context
import android.content.Intent;
import android.content.SharedPreferences; // Import SharedPreferences
import android.os.Bundle;
import android.view.View;
import android.widget.Button; // Import Button

import com.example.weighttrackapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class WeightDataActivity extends AppCompatActivity {

    private RecyclerView dataRecyclerView;
    private WeightDataAdapter adapter;
    private List<WeightEntry> weightData;
    private DatabaseHelper dbHelper;
    private FloatingActionButton addDataButton;
    private SharedPreferences sharedPreferences; // Add SharedPreferences
    private Button logoutButton; // Declare the logout button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display); // Use the layout with the logout button

        dbHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE); // Initialize SharedPreferences
        dataRecyclerView = findViewById(R.id.dataRecyclerView);
        addDataButton = findViewById(R.id.addDataButton);
        logoutButton = findViewById(R.id.logoutButton); // Initialize the logout button

        dataRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Retrieve the logged-in user's ID
        String loggedInUser = sharedPreferences.getString("loggedInUser", null);

        // Load weight data from the database for the specific user
        if (loggedInUser != null) {
            weightData = dbHelper.getAllWeightEntries(loggedInUser);
            adapter = new WeightDataAdapter(this, weightData);
            dataRecyclerView.setAdapter(adapter);
        }

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WeightDataActivity.this, AddDataActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the logout button
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear the logged-in user from SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.remove("loggedInUser");
                editor.apply();

                // Navigate back to the login activity
                Intent intent = new Intent(WeightDataActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Close the current activity
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload data when the activity resumes (e.g., after adding new data)
        String loggedInUser = sharedPreferences.getString("loggedInUser", null);
        if (loggedInUser != null) {
            weightData.clear();
            weightData.addAll(dbHelper.getAllWeightEntries(loggedInUser));
            adapter.notifyDataSetChanged();
        }
    }
}