package com.example.weighttrackapp.ui.theme;

// CreateAccountActivity.java


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.weighttrackapp.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class CreateAccountActivity extends AppCompatActivity {

    private TextInputLayout newUsernameLayout;
    private TextInputEditText newUsernameEditText;
    private TextInputLayout newPasswordLayout;
    private TextInputEditText newPasswordEditText;
    private Button createButton;
    private Button cancelButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        dbHelper = new DatabaseHelper(this);

        newUsernameLayout = findViewById(R.id.newUsernameLayout);
        newUsernameEditText = findViewById(R.id.newUsernameEditText);
        newPasswordLayout = findViewById(R.id.newPasswordLayout);
        newPasswordEditText = findViewById(R.id.newPasswordEditText);
        createButton = findViewById(R.id.createButton);
        cancelButton = findViewById(R.id.cancelButton);

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = newUsernameEditText.getText().toString().trim();
                String password = newPasswordEditText.getText().toString().trim();

                if (username.isEmpty()) {
                    newUsernameLayout.setError("Username is required");
                } else if (dbHelper.checkUserExists(username)) {
                    newUsernameLayout.setError("Username already exists");
                } else {
                    newUsernameLayout.setError(null);
                }

                if (password.isEmpty()) {
                    newPasswordLayout.setError("Password is required");
                } else {
                    newPasswordLayout.setError(null);
                }

                if (!username.isEmpty() && !password.isEmpty() && !dbHelper.checkUserExists(username)) {
                    if (dbHelper.addUser(username, password)) {
                        Toast.makeText(CreateAccountActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                        finish(); // Go back to the login screen
                    } else {
                        Toast.makeText(CreateAccountActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the login screen
            }
        });
    }
}
